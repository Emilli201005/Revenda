package br.com.emilligomes.revenda;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RevendaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RevendaApplication.class, args);
	}

}
