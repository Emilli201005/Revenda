package br.com.emilligomes.revenda.model;

public enum Color {
    BRANCO,VERMELHO,AZUL,PRETO,PRATA
}
