package br.com.emilligomes.revenda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RevendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
